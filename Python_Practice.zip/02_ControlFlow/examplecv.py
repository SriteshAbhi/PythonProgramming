a=[3,8,9,10,16]
b=[1,2,3,7,8,9,10,10,12,15,16,19,20]
c=[]
for i in range(len(a)):
    for j in range(len(b)):
        if a[i]>b[j]:
            c.append(b[j])
        break
print(c)

