number_inputs=(input())
numbers=(input())
list1=numbers.split()
list2=[]
for num in list1:
    list2.append(int(num))
max=list2[0]
for i in range(1,len(list2)):
    if list2[i]>max:
        max=list2[i]
print(max)