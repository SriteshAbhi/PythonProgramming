#WRITE A PROGRAM TO PRINT SUM OF FACTORIALS OF DATA AVAILABLE IN A SINGLE LINKED LIST CONSTRAINTS DATA <=7 1 2 3
num=int(input())
list1=[]
x=(input().split())
for k in x:
    list1.append(int(k))
lenOf