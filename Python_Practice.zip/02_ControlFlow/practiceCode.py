for i in range(1,6):
    print("  "*(5-i),end="")
    for j in range(1,i+1):
        print(j,end=" ")
    for io in range(i-1,0,-1):
        print(io,end=" ")
    print()
for ip in range(4,0,-1):
    print("  "*(5-ip),end="")
    for ic in range(1,ip+1):
        print(ic,end=" ")
    for im in range(ip-1,0,-1):
        print(im,end=" ")
    print()
    
