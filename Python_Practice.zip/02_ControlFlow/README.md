# 02_ControlFlow

This folder contains Python programs classified under **02_ControlFlow**.

## Files
- `example7.py`
- `examplecv.py`
- `hello.py`
- `my.py`
- `pr3.py`
- `practice.py`
- `practice2.1.py`
- `practiceCode.py`
- `project_2.py`

## How to run
1. `python <file_name>.py`
