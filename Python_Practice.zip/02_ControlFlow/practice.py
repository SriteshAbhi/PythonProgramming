#n=int(input("Enter the Number:"))
while(True):
  n=int(input("Enter the Number:"))

  match n:
     case 1:
        print("case 1")
     case 2:
        print("case 2")
        
     case 3:
        print("case 3")
     case 4:
        print("case 4")
     case _:
        print("wrong number match not Found")