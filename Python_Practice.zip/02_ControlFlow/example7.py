 
s=input()
d="0123456789"
sum1=0
for i in s:
   if i in d:
      sum1+=int(i)
r=sum1**3
if r<100000:
   print(r)
else:
   print("out of range")

