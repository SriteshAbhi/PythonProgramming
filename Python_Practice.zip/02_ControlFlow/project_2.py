print("HELLO USER AARE YOU READY")
print("LETS START THE GAME NOW")
import random

number=random.randint(0,10)
user_value=int(input("Enter the number between 0-10:"))
counter=0
while(number!=user_value):
    if user_value < number:
        print("HIGHER THE NUMBER")
        new=int(input())
        user_value=new
        counter+=1
    elif user_value > number:
        print('LOWER THE NUMBER')
        new2=int(input())
        user_value=new2
        counter+=1
print(f"YOUR NUMBER={user_value}|LUCKY NUMBER IS={number}| NUMBER OF ATTEMPTS={counter}")
