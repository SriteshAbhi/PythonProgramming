num=int(input())
d=list(num)
sum=0
for i in d:
    if int(i)%2==0:
        sum+=int(i)

print(sum)
