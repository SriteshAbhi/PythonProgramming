try:
    with open("sritessh.txt","r") as x:
        content=x.read()
    if "heyy" in content.lower():
        print("its there")
    else:
        print("not found")
except FileNotFoundError:
    print("File not found exception")
