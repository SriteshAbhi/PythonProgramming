 lappy=Laptop("Dell","Inspiron",60000,10)
   #  x1=lappy.discountRet(price,discount)   
   #  print(f"{brand} {model},{price},{x1}") 