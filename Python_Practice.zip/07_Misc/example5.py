n=(input())
m=(input())
print("Are the two values the same object?",id(n)==id(m))
print("Are the two valuesthe same object?",id(n)!=id(m))