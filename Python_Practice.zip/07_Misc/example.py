num=int(input("Enter the no1:"))
num1=int(input("Enter the no2:"))
operator=input("Enter the operator:")

match operator:
      
      case "-": 
          print(float(num-num1))
      case "+":
            print(float(num+num1))
      case "*":
            print(float(num*num1))
      case "/":
            print(float(num/num1))
      case "%":
            print(float(num%num1))
      case "//":
            print(float(num//num1))
      case "**":
            print(float(num**num1))

