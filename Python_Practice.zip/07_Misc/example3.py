n=int(input())
m=int(input())
print(bool(n & m))
print(bool(n | m))
 
 
print(not(n))
print(not(m))