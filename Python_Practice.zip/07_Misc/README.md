# 07_Misc

This folder contains Python programs classified under **07_Misc**.

## Files
- `example.py`
- `example1.py`
- `example2.py`
- `example3.py`
- `example4.py`
- `example5.py`
- `example_1.py`
- `hell.py`
- `linkedList1.py`
- `practice3.py`
- `tempCodeRunnerFile.py`

## How to run
1. `python <file_name>.py`
