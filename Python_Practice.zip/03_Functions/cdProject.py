# Program: Recognize Valid Identifiers and Keywords from Input File

import keyword
import re

# Function to check if a string is a valid identifier
def is_valid_identifier(s):
    """
    Checks if the given string 's' is a valid Python identifier.
    Rules:
      - Starts with a letter (A-Z or a-z) or underscore (_)
      - Can contain letters, digits (0-9), or underscores
    """
    pattern = r'^[A-Za-z_][A-Za-z0-9_]*$'
    return re.match(pattern, s) is not None

# Read input file
input_file = 'sritessh.txt'  # Replace with your file name

try:
    with open(input_file, 'r') as file:
        text = file.read()
except FileNotFoundError:
    print(f"Error: File '{input_file}' not found.")
    exit()

# Split text into words/tokens (considering separators like space, comma, semicolon, etc.)
words = re.findall(r'\b\w+\b', text)

# Initialize lists to store keywords and valid identifiers
valid_identifiers = []
keywords_found = []

# Check each word
for word in words:
    if keyword.iskeyword(word):
        keywords_found.append(word)
    elif is_valid_identifier(word):
        valid_identifiers.append(word)

# Remove duplicates
valid_identifiers = list(set(valid_identifiers))
keywords_found = list(set(keywords_found))

# Display results
print("\n--- Keywords found in file ---")
print(keywords_found if keywords_found else "No keywords found.")

print("\n--- Valid identifiers found in file ---")
print(valid_identifiers if valid_identifiers else "No valid identifiers found.")
