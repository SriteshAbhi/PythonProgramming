# 03_Functions

This folder contains Python programs classified under **03_Functions**.

## Files
- `cdProject.py`
- `crtday3.py`
- `crtday3_2.py`
- `hello.py`
- `hellobro.py`
- `practice.py`
- `practice1.py`
- `practice2.py`

## How to run
1. `python <file_name>.py`
