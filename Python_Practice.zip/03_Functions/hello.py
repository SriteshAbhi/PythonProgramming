import random
def get_Winner(user,computer):
    if user==computer:
        return "Tie"
    elif (user=="water" and computer=="gun" or user=="snake" and computer=="water" or user=="gun" and computer=="snake"):
        return "you won"
    else:
        return "you loss"
while True:
    print("welcome to the snake water game:")
    print("Enter your option(snake,water or gun):")
    user_option=input()

    computer_option=random.choice(["water","gun","snake"]) 
    x=get_Winner(user_option,computer_option)
    print(f"{x} because the opponent is {computer_option}")
    
 
    