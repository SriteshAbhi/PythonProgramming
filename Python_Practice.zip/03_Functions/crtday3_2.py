 
def isprime(num):
    count=0
    for i in range(1,num+1):
            if num%2==0:
                count+=1
    if count==2:
        return True
    else:
        return False
    
 
            
'''def sumofprime(num2):
    for k in range(1,num2):
         a=isprime(k)
         b=isprime(num2-k)
         if  a and b:
             print(k,"+",num2-k,"=",num2)'''
    

def isprime2(n):
     for m in range(2,n//2+1):
          if n%m==0:
               return False
     return True
n1=int(input())
for l in range(2,n1//2+1):
     if isprime(l) & isprime(n1-l):
          print(l,"+",n1-l,"=",n1)
 