def levelsCheck(health,m,x,y,num):
   count=0
   
   for i in range(num):
      cot=health
      mot=x[i]
       
      if cot>=x[i]:
         count+=1
         cot+=m[x[i]]
   return count
         
   
if __name__=="__main__":
 while True:
    NoLEVELS=int(input())
    exp=int(input())
    Monsters=[]
    bonus=[]
    for i in range(0,NoLEVELS):
       x=int(input())
       Monsters.append(x)
    for j in range(0,NoLEVELS):
       y=int(input())
       bonus.append(y)
    d={}
    for k in range(NoLEVELS):
       d[Monsters[k]]=bonus[k]
    Monsters.sort()
       
    r=levelsCheck(exp,d,Monsters,bonus,NoLEVELS)
    print("NO OF LEVELS CLEARED:",r)
    print("ENTER THE GAME ELEMENTS BELOW->:")

