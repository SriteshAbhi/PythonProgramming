def add_contact():
    name=input("Enter the name:")
    number=input("Enter the number:")
    with open("contacts.txt","a+") as d:
        d.write(f"{name}-{number}\n")
def display_contact():
    with open("contacts.txt","r") as f:
        print("----------contacts---------")
        f.seek(0)
        print(f.read())
def serch_contact():
    found=False
    key=input("Enter the key:")
    with open("contacts.txt","r") as m:
        m.seek(0)
        for file in m:
            if key in file.lower():
               print("found ", file.strip())
               found=True
    if not found:
        print("invalid contact o key")
def delete_contact():
    name_to_delete = input("Enter name to delete: ").lower()
    deleted = False

    with open("contacts.txt", "r") as file:
        lines = file.readlines()

    with open("contacts.txt", "w") as file:
        for line in lines:
            if name_to_delete not in line.lower():
                file.write(line)
            else:
                deleted = True

    if deleted:
        print(f"🗑️ Contact with name '{name_to_delete}' deleted.")
    else:
        print("❌ Contact not found.")

                
                
while True:
    print("1.add contact\n2.display")
    choice=int(input("Enter choice:"))
    if choice==1:
        add_contact()
    elif choice==2:
        display_contact()
    elif choice==3:
        serch_contact()
    elif choice==4:
        delete_contact()
