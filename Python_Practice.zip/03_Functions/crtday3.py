"""WRITE A PROGRAM TO CHECK WETHER A GIVEN NUMBER CAN BE REPRESENTED AS SUM OF TWO EVEN NUMBERS OR NOT IF
YES PRINT ALL SUCH PAIRS OTHER WISE NO"""
def sumofeven(num):
    if(num>2 & num%2==0):
        for i in range(2,num//2+1,2):
            for j in range(2,num-1,2):
                if i+j==num:
                    print(f"{i}+{j}={i+j}")
    else:
        print("not possible")

def sumofodd2(num1):
    if( num1>1 & num1%2==0):
        print("no")
    for i in range(1,num1//2+1,1):
            print(i,"+",num1-i,"=",num1)

#s=sumofeven(10)
b=sumofodd2(10)
                



