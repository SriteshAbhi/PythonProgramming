from collections import deque
def totalExpenditureCheck(stack1,stack2,size):
    total=0
    for i in range(0,size):
        x=stack1.pop()
        y=stack2.pop()
    
        z=x*y
        total=total+z
    return total


if __name__=="__main__":
    stack1=deque()
    stack2=deque()
    noOfItems=int(input("enter the no of items:"))
    x=input()
    list1Qantity=x.split()
    for items in list1Qantity:
        stack1.append(int(items))
    y=input("enter the units cost:")
    unitCost=y.split()
    for ko in unitCost:
         stack2.append(int(ko))
    ans=totalExpenditureCheck(stack1,stack2,noOfItems)
    print("total expenditure:",ans)
    




