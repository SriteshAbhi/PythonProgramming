class Bank:
    def __init__(self,name,balance):
        self.__name=name
        self.__balance=balance
    def show(self):
        print(f"Name:{self.__name} Balance:{self.__balance}")
    def deposit(self,amount):
        self.amount=amount
        self.__balance+=self.amount
        print(f"Deposit success>>>>\n Name:{self.__name} updated Balance:{self.__balance}")
    def withdraw(self,amount):
        self.amount=amount
        if self.__balance - self.amount >=0:
            self.__balance-=self.amount
            print(f"Withdreawl succes>>>>\nName:{self.__name}  Remaning Balance:{self.__balance}")
        else:
            print("Invalid Amount")
per=Bank("sritesh",100000)
per.show()
per.deposit(20000)
per.withdraw(20000)