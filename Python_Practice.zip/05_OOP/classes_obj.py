class student:
     def __init__(self,name,roll):
          self.name=name
          self.roll=roll
     def show_details(self):
        print(f"Name={self.name}\nRollNo={self.roll}")
class book:
    def __init__(self,title,author):
        self.title=title
        self.author=author
    def display(self):
        print(f"Author={self.author}\nTitle={self.title}")
class circle:
    def __init__(self):
        self.radius=int(input("Enter the radius:"))
    def area(self):
        print("Area=", 3.14 *(self.radius*self.radius))
    def perimeter(self):
        print("Prerimeter=",2*3.14*self.radius)
    def diameter(self):
        print("diameter=",2*self.radius)
c=circle()
c.area()
c.perimeter()
c.diameter()
        
# m=book("jamesbond","bond")
# m.display()
# s=student("sritessh",2)
# s.show_details()
     
