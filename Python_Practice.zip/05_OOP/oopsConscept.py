class Mobile:
    def __init__(self,brand,price):
        self.brand=brand
        self.price=price
    def display(self):
        print(f"Brand:{self.brand} Price:{self.price}")
# m=Mobile("Realme C3",12999)
# m.display()
class Vechile:
    def __init__(self,brand,model):
        self.brand=brand
        self.model=model
    def info(self):
        print(f"Brand:{self.brand} Model:{self.model}")
class Bike(Vechile):
    def bikeType(self):
        print(f"{self.model}/{self.brand} is a two-wheeler")
# bike=Bike("honda","xve-10")
# bike.info()
# bike.bikeType()
class Battery:
    def status(self,level):
        if level in range(50,100):
            print("Battery level is good")
        else:print("battery level is bad")
class Phone:
    def __init__(self):
        print("Enter the percentage:")
        self.per=int(input())
        self.batt=Battery()
    def condition(self):
        self.batt.status(self.per)
p=Phone()
p.condition()

        