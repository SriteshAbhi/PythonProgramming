# 05_OOP

This folder contains Python programs classified under **05_OOP**.

## Files
- `BankAcc.py`
- `ClassObj1.py`
- `QueuesLinkdList.py`
- `TREES.PY`
- `circularLinkedList.py`
- `circularSingle.py`
- `classes_obj.py`
- `doubleLinkedList.py`
- `encapsulation.py`
- `ex1.py`
- `hello1.py`
- `oopsConscept.py`
- `polymorphisum.py`

## How to run
1. `python <file_name>.py`
