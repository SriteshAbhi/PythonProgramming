class bank:
    def __init__(self,accNo,balance=0):
        self.accNo=accNo
        self.balance=balance
    def deposit(self,ammount):
         self.balance+=ammount
         print("succes new bal=",self.balance)
    def withdraw(self,ammount):
        if ammount<=self.balance:
         self.balance-=ammount
         print("succes new bal=",self.balance)
        else:cd
            print('insufficient bal')
x=bank(1234)
x.deposit(20000)
x.withdraw(20000)