from math import factorial


class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
class QueueLinked:
    def __init__(self):
        self.head=None
    def Enqueue(self,data):
        new=Node(data)
        if self.head is None:
            self.head=new
        else:
            current=self.head
            while current.next is not None:
                current=current.next
            current.next=new
    def Dequeue(self):
        if self.head is None:
            print("not ")
        elif self.head.next is None:
            self.head=None
        else:
         self.head=self.head.next
    def Peek(self):
        print(self.head.data)
    def IsEmpty(self):
        if self.head is None:
            return True
        else:
            return False
    def Display(self):
        if self.head is None:
            print("Not Possible")
        else:
            current=self.head
            while current is not None:
                print(current.data,end=" Q ")
                current=current.next
            print()

class stack:
    def __init__(self):
        self.head=None
    def append
     
if __name__=="__main__":
    que=QueueLinked()
    que.Enqueue(1)
    que.Enqueue(2)
    que.Enqueue(3)
    que.Enqueue(4)
    que.Enqueue(5)
    que.Display()
    que.Dequeue()
    que.Display()
    que.Peek()
    

    
