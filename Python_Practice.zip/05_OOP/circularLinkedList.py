class Node:
    def __init__(self,data):
        self.data=data
        self.next=self.prev=None

class circularLinked:
    def __init__(self):
        self.head=None

    def add(self,data):
        new_node=Node(data)
        if self.head is None:
            self.head=new_node
            new_node.next=self.head
            new_node.prev=self.head
        else:
            current=self.head
            while current.next is not self.head:
                current=current.next
            current.prev.next=new_node
            new_node.prev=current.prev
            new_node.next=current
            current.prev=new_node
            

    def display(self):
        if self.head is None:
            print("Empty")
        else:
            current=self.head
            while current.next is not self.head:
                print(current.data,end="<->")
                current=current.next
            print(f"{current.data}<->{self.head.data}")

    def addBeg(self,data):
        new=Node(data)
        if self.head is None:
            self.head=new
            new.next=self.head
            new.prev=self.head
        else:
            current=self.head
            current.prev.next=new
            new.prev=current.prev
            new.next=current
            current.prev=new
            self.head=new

    def addAtpos(self,data,pos):
        new=Node(data)
        if self.head is None:
            print("Empty")
        else:
            count=1
            current=self.head
            while count!=pos and current.next is not self.head:
                count+=1
                current=current.next
            if current.next is self.head:
                current.next=new
                new.prev=current
                new.next=self.head
                self.head.prev=new
            
            else:
                new.next=current.next
                current.next.prev=new
                current.next=new
                current.next.prev=new
    #def addArData(self,data,data1):

    
    def delBeg(self):
        if self.head is None:
            print("Empty")
        else:
            if self.head.next is self.head.prev:
                self.head=None
            else:
                current=self.head
                current.next.prev=current.prev
                current.prev.next=current.next
                self.head=current.next

    def deleLast(self):
        if self.head is None:
            print("not possible")
        else:
            if self.head.next is self.head.prev:
                self.head=None
            else:
                current=self.head
                while current.next is not self.head:
                    current=current.next
                current.next.prev=current.prev
                current.prev.next=current.next
                self.head=current.next

    def deletePos(self,pos):
        if self.head is None:
            print("not possible")
        elif pos==1 and self.head.next is self.head.prev:
                self.head=None
        else:
            current=self.head
            count=1
            while count!=pos:
                count+=1
                current=current.next
            if pos==1:
                current.next.prev=current.prev
                current.prev.next=current.next
                self.head=current.next

            elif pos!=1 and current.next is not self.head:
                 current.next.prev=current.prev
                 current.prev.next=current.next
            
            else:
                current.next.prev=current.prev
                current.prev.next=current.next
                self.head=current.next

        
                       
            

if __name__=="__main__":
    circle=circularLinked()
    circle.add(10)
    circle.add(15)
    circle.display()
    circle.addAtpos(16,1)
    circle.addAtpos(17,2)
    
    circle.display()

