class Shape:
    def area(self):
        print("Calculating area.....")
class Rectangle(Shape):
    def area(self):
        print("Enter the lenght:")
        self.length=int(input())
        print('Enter the breadth:')
        self.breadth=int(input())
        super().area()
        print(f"AREA:{self.length*self.breadth}")
class circle(Shape):
    def area(self):
        print("Enter the radius:")
        self.radius=int(input())
        super().area()
        print(f"AREA:{3.14*(self.radius**2)}")
for ar in (Rectangle(),circle()):
    ar.area()