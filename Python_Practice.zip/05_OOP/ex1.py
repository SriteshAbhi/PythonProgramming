 
class queue2:
    def append(self,data):
        queue.append(data)
    def Dequeue(self):
         queue.pop(0)
 
 
if __name__=="__main__":
    queue1=queue2()
    queue=[]
    queue1.append(1)
    queue1.append(2)
    print(queue)
    queue1.Dequeue()
    print(queue)

