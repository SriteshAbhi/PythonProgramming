class Laptop:
     def discountRet(self,price,discount):
        x=price*(discount/100)
        discountPrice=price-x
        return discountPrice
if __name__=="--main__":
    brand=input()
    model=input()
    price=int(input())
    discount=int(input())
    lappy=Laptop()
    x1=lappy.discountRet(price,discount)   
    print(f"{brand} {model},{price},{x1}")  