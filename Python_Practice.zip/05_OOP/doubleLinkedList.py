class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
        self.prev=None
class doubleLinked:
    def __init__(self):
        self.head=None

    def add(self,data):
        new_node=Node(data)
        if self.head is None:
            self.head=new_node
        else:
            current=self.head
            while current.next is not None:
                
                  current=current.next
            new_node.prev=current
            current.next=new_node

    def display(self):
        if self.head is None:
            print("empty")
        else:
            current=self.head
            while current is not None:
                print(current.data,end="->")
                current=current.next
            print("Null")
            
    def displayRev(self):
        if self.head is None:
            print("empty")
        else:
            current=self.head
            while current.next is not None:
                 current=current.next
            while current.prev is not None:
                print(current.data,end="<->")
                current=current.prev
            print(current.data,"->Null")
            

    

    def addAtBeg(self,data):
        new_node=Node(data)
        if self.head is None:
            self.head=new_node
        else:
            current=self.head
            
            current.prev=new_node
            new_node.next=current
            self.head=new_node

    def addAtposition(self,data1,data2):
        if self.head is None:
            print("not possible empty")
        else:
            new_node1=Node(data1)
            current=self.head
            if():
             while current.data!=data2:
                current=current.next
             if current.next is not None:
              current.next.prev=new_node1
              new_node1.next=current.next
              current.next=new_node1
              new_node1.prev=current
             else:
                current.next=new_node1
                new_node1.prev=current
            else:
                print("not found")
    def addAtCount(self, data3, num):

     new = Node(data3)
    
    # If the list is empty
     if self.head is None:
        print("Empty")
        return

    # Case when inserting at the beginning (num == 1)
     if num == 1:
        new.next = self.head
        self.head.prev = new
        self.head = new
        return

    # Traverse the list to find the position to insert the new node
    current = self.head
    count = 1
    
    while current is not None and count < num:
        current = current.next
        count += 1
    
    # If we've reached the desired position
    if current is not None:
        new.prev = current.prev
        new.next = current
        if current.prev is not None:
            current.prev.next = new
        current.prev = new
    else:
        # Insert at the end if num is greater than the length of the list
        current = self.head
    




    def deleteBeg(self):
        current=self.head
        if self.head is None:
            print("the list is empty")
        elif current.next is None:
            self.head=None
        else:
         
            current.next.prev=current.prev
            self.head=current.next
           
           

    def deleteAtPos(self,data1):
        if self.head is None:
            print("Empty")
        elif self.head.data==data1 and self.head.next is None:
            self.head=None
        else:
            current=self.head
            while current.data!=data1:
                current=current.next
            if current.next is not None:
               current.next.prev=current.prev
               current.prev.next=current.next
            else:
                current.prev.next=None

    def deleteCount(self,pos):
        if self.head is None:
            print("empty")
        elif pos==1 and self.head.next is None:
           self.head=None
        else:
            count=1
            current=self.head
            while count!=pos:
                current=current.next
                count+=1
            if pos==1 and current.next is not None:
                current.next.prev=None
                self.head=current.next
            elif pos!=1 and current.next is not None:
                current.next.prev=current.prev
                current.prev.next=current.next
                
            else:
                current.prev.next=None
            



    def deleteAtEnd(self):
        if self.head is None:
            print("empty not possible")
        elif self.head.next is None:
            self.head=None
        
        else:
            current=self.head
            while current.next is not None:
                current=current.next
            current.prev.next=None

if __name__=="__main__":
    double=doubleLinked()
    double.add(10)
    double.add(20)
    double.add(30)
    double.display()
    double.addAtCount(40,3)
    double.display()



