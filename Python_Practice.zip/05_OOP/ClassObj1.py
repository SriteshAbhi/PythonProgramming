class car:
    def __init__(self,brand,model,year):
        self.brand=brand
        self.model=model
        self.year=year
        print(brand,model,year)
x=car("hundai","i10",2019)


    
        