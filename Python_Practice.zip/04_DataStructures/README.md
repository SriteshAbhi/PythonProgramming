# 04_DataStructures

This folder contains Python programs classified under **04_DataStructures**.

## Files
- `example6.py`

## How to run
1. `python <file_name>.py`
