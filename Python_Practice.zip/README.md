# python-practice-codes

This repository contains my Python practice programs merged from two uploads.
Files are organized topic-wise to make the repository easy to browse and presentable.

## Topics / Folder Structure
- `01_Basics` — beginner scripts and simple examples.
- `02_ControlFlow` — if/else, loops, pattern programs.
- `03_Functions` — functions and recursion.
- `04_DataStructures` — lists, dicts, sets, tuples examples.
- `05_OOP` — classes, objects, inheritance, polymorphism.
- `06_Advanced` — numpy, pandas, matplotlib, ML-related scripts.
- `07_Misc` — scripts that couldn't be auto-classified.

## How to use
1. Install required Python (3.x) and libraries if needed.
2. Run scripts: `python file_name.py` or `python3 file_name.py`.

## Notes
- I can further clean filenames, add examples to README per folder, or add a requirements.txt if you want.
