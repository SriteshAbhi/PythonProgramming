# 06_Advanced

This folder contains Python programs classified under **06_Advanced**.

## Files
- (no files)

## How to run
1. `python <file_name>.py`
