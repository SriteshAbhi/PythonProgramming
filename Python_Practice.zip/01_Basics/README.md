# 01_Basics

This folder contains Python programs classified under **01_Basics**.

## Files
- (no files)

## How to run
1. `python <file_name>.py`
